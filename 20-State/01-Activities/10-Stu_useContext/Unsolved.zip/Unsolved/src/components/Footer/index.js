import React from "react";
import "./style.css";

function Footer() {
  return (
    <footer className="footer">
      <span>Wikipedia Searcher</span>
    </footer>
  );
}

export default Footer;
